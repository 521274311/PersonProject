#通过sys包导入lib依赖包
import sys
import os
import random
import configparser
def getLibDir(path,split='project'):
    path = path.split(split)
    #print(path[0])
    
    try:
        file_dir = path[0]+split+r'\lib'
    except Exception:
        print('无法加载lib目录')
    return file_dir

#添加lib目录到sys.path中
path = os.getcwd()

#如果修改项目根目录此处需要添加split参数
path = getLibDir(path) #可能修改处

sys.path.append(path)
#导入核心生成器类
from generator import Generator

'''
auther: dragons
date: 2018-10-17
'''


#读取lib\config.ini配置文件信息，返回数据列表
def getDatas():
    conf = configparser.ConfigParser()
    conf.read(path+r'\config.ini')
    functions = conf.options('function')
    lens = int(conf['function']['lens'])
    datas_ex = ['-1' for i in range(100)]
    start_consistency = int(conf['basic']['start_consistency'])
    consistencys = conf.options('consistency')
    consistency_datas = []
    for i in consistencys:
        if i != 'count':
            consistency_datas.extend(conf['consistency'][i].split(','))
    
    for func in functions:
        value = int(conf['function'][func])
        if func!='lens' and value != 0:
            tp = func.split('-')[0]
            if tp == 'int' and (start_consistency == 0 or func not in consistency_datas):
                try:
                    mins = int(conf[func]['mins'])
                    maxs = int(conf[func]['maxs'])
                    datas_ex[value] = Generator.getInts(mins,maxs,lens)
                except:
                    datas_ex[value] = Generator.getInts()
            elif tp == 'int':
                continue
            if tp == 'float' and (start_consistency == 0 or func not in consistency_datas):
                try:
                    mins = int(conf[func]['mins'])
                    maxs = int(conf[func]['maxs'])
                    decimal = int(conf[func]['decimal'])
                    datas_ex[value] = Generator.getFloats(mins,maxs,decimal,lens)
                except:
                    datas_ex[value] = Generator.getFloats()
            elif tp == 'float':
                continue
            if tp == 'str' and (start_consistency == 0 or func not in consistency_datas):
                try:
                    mins = int(conf[func]['mins'])
                    maxs = int(conf[func]['maxs'])
                    char_all = list(map(lambda x:x.split(';'),conf.get(func,'char_all').split('|')))
                    chance = list(map(lambda x:x.split(':'),conf.get(func,'chance').split(',')))
                    chance = dict(list(map(lambda x: list(map(lambda y: int(y),x)),chance)))
                    datas_ex[value] = Generator.getStrs(mins,maxs,lens,char_all,chance)
                except:
                    datas_ex[value] = Generator.getStrs()
            elif tp == 'str':
                continue
            if tp == 'datetime' and (start_consistency == 0 or func not in consistency_datas):
                try:
                    mins = str(conf[func]['mins'])
                    maxs = str(conf[func]['maxs'])
                    datas_ex[value] = Generator.getDateTimes(mins,maxs,lens)
                except:
                    datas_ex[value] = Generator.getDateTimes()
            elif tp == 'datetime':
                continue
            if tp == 'ip' and (start_consistency == 0 or func not in consistency_datas):
                try:
                    datas_ex[value] = Generator.getIps(lens)
                except:
                    datas_ex[value] = Generator.getIps()
            elif tp == 'ip':
                continue
            if tp == 'name' and (start_consistency == 0 or func not in consistency_datas):
                try:
                    datas_ex[value] = Generator.getChineseNames(lens)
                except:
                    datas_ex[value] = Generator.getChineseNames()
            elif tp == 'name':
                continue
            if tp == 'phone' and (start_consistency == 0 or func not in consistency_datas):
                try:
                    datas_ex[value] = Generator.getPhones(lens)
                except:
                    datas_ex[value] = Generator.getPhones()
            elif tp == 'phone':
                continue
        else:
            continue
        print()
    datas = []
    if start_consistency == 1:
        consistencys = conf.options('consistency')
        #print(consistencys)
        for i in consistencys:
            if i != 'count':
                dt = getConsistencyDatas(i)
                for i in range(len(dt)):
                    if isinstance(dt[i],list):
                       datas_ex[i] = dt[i]
    
    for data in datas_ex:
        if  isinstance(data,list):
            datas.append(data)
    datas = list(zip(*datas))
    return datas

#获取一致性数据
def getConsistencyDatas(name='name'):
    conf = configparser.ConfigParser()
    conf.read(path+r'\config.ini')
    functions = conf.options('function')
    lens_all = int(conf['function']['lens'])
    datas_ex = ['-1' for i in range(100)]
    lens = int(conf[name]['count'])
    consistency_name = conf['consistency'][name].split(',')
    random_all = []
    for i in range(lens_all):
        random_all.append(random.randint(0,lens-1))
    for func in consistency_name:
        tp = func.split('-')[0]
        value = int(conf['function'][func])
        if tp == 'int':
            try:
                mins = int(conf[func]['mins'])
                maxs = int(conf[func]['maxs'])
                dt = Generator.getInts(mins,maxs,lens)
                dd = []
                for i in random_all:
                    dd.append(dt[i])
                datas_ex[value] = dd
            except:
                datas_ex[value] = Generator.getInts()
        elif tp == 'float':
            try:
                mins = int(conf[func]['mins'])
                maxs = int(conf[func]['maxs'])
                decimal = int(conf[func]['decimal'])
                dt = Generator.getFloats(mins,maxs,decimal,lens)
                dd = []
                for i in random_all:
                    dd.append(dt[i])
                datas_ex[value] = dd
            except:
                datas_ex[value] = Generator.getFloats()
        elif tp == 'str':
            try:
                mins = int(conf[func]['mins'])
                maxs = int(conf[func]['maxs'])
                char_all = list(map(lambda x:x.split(';'),conf.get(func,'char_all').split('|')))
                chance = list(map(lambda x:x.split(':'),conf.get(func,'chance').split(',')))
                chance = dict(list(map(lambda x: list(map(lambda y: int(y),x)),chance)))
                dt = Generator.getStrs(mins,maxs,lens,char_all,chance)
                dd = []
                for i in random_all:
                    dd.append(dt[i])
                datas_ex[value] = dd
            except:
                datas_ex[value] = Generator.getStrs()
        elif tp == 'datetime':
            try:
                mins = str(conf[func]['mins'])
                maxs = str(conf[func]['maxs'])
                dt = Generator.getDateTimes(mins,maxs,lens)
                dd = []
                for i in random_all:
                    dd.append(dt[i])
                datas_ex[value] = dd
            except:
                datas_ex[value] = Generator.getDateTimes()
        elif tp == 'ip':
            try:
                dt = Generator.getIps(lens)
                dd = []
                for i in random_all:
                    dd.append(dt[i])
                datas_ex[value] = dd
            except:
                datas_ex[value] = Generator.getIps()
        elif tp == 'name':
            try:
                dt = Generator.getChineseNames(lens)
                dd = []
                for i in random_all:
                    dd.append(dt[i])
                datas_ex[value] = dd
            except:
                datas_ex[value] = Generator.getChineseNames()
        elif tp == 'phone':
            try:
                dt = Generator.getPhones(lens)
                dd = []
                for i in random_all:
                    dd.append(dt[i])
                datas_ex[value] = dd
            except:
                datas_ex[value] = Generator.getPhones()
        print()
    datas = datas_ex
    return datas

#将数据写入文件
def writeToFile(datas):
    conf = configparser.ConfigParser()
    conf.read(path+r'\config.ini')
    file_url = conf['file']['url']
    file_split = conf['file']['split']
    if file_split == '':
        file_split = ' '
    file_write_way = conf['file']['write_way']
    file_encoding = conf['file']['encoding']
    file_message = conf['file']['message']
    print('开始往文件写入数据')
    with open(file_url,('w+' if file_write_way == '0' else 'a+'),encoding=file_encoding) as f:
        bt = 0
        i = 0
        lens = len(datas)
        for data in datas:
            i += 1
            if int(i/lens*100)>=25 and bt == 0:
                print('已完成 25%')
                bt += 1
            if int(i/lens*100)>=50 and bt == 1:
                print('已完成 50%')
                bt += 1
            if int(i/lens*100)>=75 and bt == 2:
                print('已完成 75%')
                bt += 1
            line = file_split.join(data)
            f.write(line+'\n')
            f.flush()
            if file_message == '1':
                print('写入数据  '+line+'  成功')
        print('已完成 100%')
        print('写入数据完成')

if __name__ == '__main__':
    conf = configparser.ConfigParser()
    conf.read(path+r'\config.ini')
    if conf.get('basic','start_config') == '1':
        datas = getDatas()
    #------若未启动配置文件，可在此区域实现数据生成----------

    
    #-----------------------End------------------------------
    if conf.get('basic','show_window') == '1':
        try:
            print()
            print('开始显示数据信息')
            for data in datas:
                print(conf['file']['split'].join(data))
        except:
            pass
    
    if conf.get('basic','write_to_file') == '1':
        try:
            writeToFile(datas)
        except:
            pass
