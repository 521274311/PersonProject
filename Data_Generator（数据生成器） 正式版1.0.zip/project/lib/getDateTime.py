import random

#mins 最小日期 格式 yyyy-mm-dd
#maxs 最大日期 格式 yyyy-mm-dd
#lens 生成lens条日期
'''
auther: dragons
date: 2018-10-17
'''
def getDateTime(mins,maxs,lens):
    print('开始构建时间模型')
    lists = []
    i = 0
    mins_list = mins.split('-')
    maxs_list = maxs.split('-')
    #平年key value
    month_day1 = {1:31,2:28,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31}
    #闰年key value
    month_day2 = {1:31,2:29,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31}
    bt = 0
    print('时间模型构建完成')
    print('开始生成随机时间数据')
    while i < lens:
        i+=1
        if int (i / lens * 100) == 25 and bt == 0:
            print('已完成 25%')
            bt += 1
        elif int (i / lens * 100) == 50 and bt == 1:
            print('已完成 50%')
            bt += 1
        elif int (i / lens * 100) == 75 and bt == 2:
            print('已完成 75%')
            bt += 1
        year = random.randint(int(mins_list[0]),int(maxs_list[0]))
        if year != int(mins_list[0]) and year != int(maxs_list[0]):
            month = random.randint(1,12)
            if year%400==0 or (year%4==0 and year%100!=0):
                day = random.randint(1,month_day2[month])
            else:
                day = random.randint(1,month_day1[month])
        elif year == int(mins_list[0]):
            month = random.randint(int(mins_list[1]),12)
            if month == int(mins_list[1]):
                if year%400==0 or (year%4==0 and year%100!=0):
                    day = random.randint(int(mins_list[2]),month_day2[month])
                else:
                    day = random.randint(int(mins_list[2]),month_day1[month])
            else:
                if year%400==0 or (year%4==0 and year%100!=0):
                    day = random.randint(1,month_day2[month])
                else:
                    day = random.randint(1,month_day1[month])
        else:
            month = random.randint(1,int(maxs_list[1]))
            if month==int(maxs_list[1]):
                day = random.randint(1,int(maxs_list[2]))
            else:
                if year%400==0 or (year%4==0 and year%100!=0):
                    day = random.randint(1,month_day2[month])
                else:
                    day = random.randint(1,month_day1[month])
        hour = random.randint(0,23)
        minute = random.randint(0,59)
        second = random.randint(0,59)
        datetime = str(year)+'-'
        datetime += ('0'+str(month) if month<10 else str(month))+'-'
        datetime += ('0'+str(day) if day<10 else str(day))+' '
        datetime += ('0'+str(hour) if hour<10 else str(hour))+':'
        datetime += ('0'+str(minute) if minute<10 else str(minute))+':'
        datetime += '0'+str(second) if second<10 else str(second)
        #datetime = "{0}-{1}-{2} {3}:{4}:{5}".format(year,month,day,hour,minute,second)
        #print(datetime)
        lists.append(datetime)
    print('已完成 100%')
    print('生成随机时间数据成功')
    return lists

if __name__=='__main__':
    print(getDateTime('2000-01-01','2020-01-01',1000))
