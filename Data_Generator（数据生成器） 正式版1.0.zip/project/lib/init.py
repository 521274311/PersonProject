import configparser
import os
from getLibDir import *
def getConfigData(group='basic',key='project_dir_name',split='project'):
    path = os.getcwd()
    path = getLibDir(path,split)
    path = path + r"\config.ini"
    config = configparser.ConfigParser()
    config.read(path)
    return config.get(group,key)

if __name__ == '__main__':
    print(getConfigData())
