from getDateTime import *
from getInt import *
from getFloat import *
from getStr import *
from getName import *
from getPhone import *
from getFamilyName import *
from getFirstName import *

__all__ = ['getDateTime','getInt','getFloat','getStr',
           'getName','getPhone','getFamilyName','getFirstName']
