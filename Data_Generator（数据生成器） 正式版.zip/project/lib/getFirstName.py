import os
from getLibDir import *
from init import *
'''
auther: dragons
date: 2018-10-17
'''
#split 项目根目录名称
def getFirst(split='project'):
    split = getConfigData('basic','project_dir_name')
    sets = set()
    file_dir = os.getcwd()
    file_dir = getLibDir(file_dir,split)
    with open(file_dir+r"\data\first_name.txt",encoding='utf-8') as f:
        t = f.read()
        t = t.split(' ')
        for i in t:
            sets.add(i)
    return sets

if __name__=="__main__":
    sets = getFirst()
    print(sets)
