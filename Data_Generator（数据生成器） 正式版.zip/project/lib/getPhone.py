import random

'''
auther: dragons
date: 2018-10-17
'''
def getPhone(lens):
    print('开始构建手机号码模型')
    #移动、联通、电信、虚拟
    carrieroperator = [['134','135','136','137','138','139','150','151','152','157','158','159','178','182','184','187','188','198'],['130','131','132','155','156','185','186','145','176'],['133','153','177','180','181','189','199'],['170','171']]
    lists = []
    i = 0
    bt = 0
    print('手机号码模型构建完成')
    print('开始随机生成手机号码数据')
    while i < lens:
        i += 1
        if int (i / lens * 100) == 25 and bt == 0:
            print('已完成 25%')
            bt += 1
        elif int (i / lens * 100) == 50 and bt == 1:
            print('已完成 50%')
            bt += 1
        elif int (i / lens * 100) == 75 and bt == 2:
            print('已完成 75%')
            bt += 1
        number = ''
        x = random.randint(0,3)
        number += carrieroperator[x][random.randint(0,len(carrieroperator[x])-1)]
        j = 0;
        while j < 8:
            j += 1
            number += str(random.randint(0,9))
        lists.append(number)
    print('已完成 100%')
    print('随机生成手机号码数据成功')
    return lists

if __name__=='__main__':
    print(getPhone(1000))
