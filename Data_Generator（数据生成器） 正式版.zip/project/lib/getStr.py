import random

'''
auther: dragons
date: 2018-10-17
'''
#普通字符数字下划线账号生成

#mins: 字符串最小长度（闭区间）
#maxs: 字符串最大长度（闭区间）
#lens: 生成字符串列表长度
#char_all: 字符串字典（二维列表）
#chance: 随机规则（key为从0到N的数值，value为char_all的一维下标）
def getStr(mins,maxs,lens,char_all,chance):
    i = 0
    bt = 0
    lists = []
    print('开始生成随机字符串数据')
    while i < lens:
        i += 1
        if int (i / lens * 100) == 25 and bt == 0:
            print('已完成 25%')
            bt += 1
        elif int (i / lens * 100) == 50 and bt == 1:
            print('已完成 50%')
            bt += 1
        elif int (i / lens * 100) == 75 and bt == 2:
            print('已完成 75%')
            bt += 1
        count = random.randint(mins,maxs)#用户名6到14字符
        j = 0
        strs = ''
        while j < count:
            #字符串生成规则
            t = chance[random.randint(0,len(chance)-1)]
            strs += char_all[t][random.randint(0,len(char_all[t])-1)]
            j += 1
        lists.append(strs)
    print('已完成 100%')
    print('生成随机字符串数据成功')
    return lists

if __name__=='__main__':
    print(getStr(6,14,10,[['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
                          ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
                          ['_'],
                          ['1','2','3','4','5','6','7','8','9']],
                {0:0,1:0,2:0,3:0,4:0,5:1,6:1,7:1,8:2,9:3,10:3}))
