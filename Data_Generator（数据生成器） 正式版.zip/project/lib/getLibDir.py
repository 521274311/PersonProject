'''
auther: dragons
date: 2018-10-17
'''
def getLibDir(path,split='project'):
    path = path.split(split)
    #print(path[0])
    
    try:
        file_dir = path[0]+split+r'\lib'
    except Exception:
        print('无法加载lib目录')
    return file_dir
