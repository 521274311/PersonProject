import getInt
import getFloat
import getStr
import getName
import getPhone
import getIp
import getDateTime
from init import *

class Generator:
    '''
    author: dragons
    date: 2018-10-17

    '''    
    def getInts(mins=0,maxs=1000,lens=100,start_config=True):
        '''
    Generating a list that all are int datas.
    Param：
        mins：
            Introduction: int datas' min value.
            Type: int
            Default: 0
        maxs：
            Introduction: int datas' max value.
            Type: int
            Default: 1000
        lens：
            Introduction: generated data list's length.
            Type: int
            Default: 100
        start_config:
            Introduction: this function whether or not to load config file.
            Type: boolean
            Default: True
    Return:
        Introduction: list that length is equals the lens.
        Type: list(string)
        '''
        return getInt.getInt(mins,maxs,lens)



    
    def getFloats(mins=0,maxs=1000,decimal=2,lens=100,start_config=True):
        '''
    Generating a list that all are float datas.
    Param：
        mins：
            Introduction: float datas' min value.
            Type: float
            Default: 0
        maxs：
            Introduction: float datas' max value.
            Type: float
            Default: 1000
        decimal:
            Introduction: digits after decimal point.
            Type: int
            Default: 2
        lens：
            Introduction: generated data list's length.
            Type: int
            Default: 100
        start_config:
            Introduction: this function whether or not to load config file.
            Type: boolean
            Default: True
    Return:
        Introduction: list that length is equals the lens.
        Type: list(string)
        '''
        
        return getFloat.getFloat(mins,maxs,decimal,lens)



    
    def getStrs(mins=6,maxs=16,lens=100,char_all=[['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
                                                  ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
                                                  ['_'],
                                                  ['0','1','2','3','4','5','6','7','8','9']],
                chance={0:0,1:0,2:0,3:0,4:0,5:1,6:1,7:1,8:2,9:3,10:3},start_config=True):
        '''
    Generating a list that all are string datas.
    Param：
        mins:
            Introduction: string datas' min length.
            Type: int
            Default: 6
        maxs:
            Introduction: string datas' max length.
            Type: int
            Default: 16
        lens：
            Introduction: string data list's length.
            Type: int
            Default: 100
        char_all:
            Introduction: two dimension list that be used to generate strings.first dimension list is a group that the similar datas.
            Type: list(list(char|string)) (warn: not digit. if you want please enter example '1')
            Default: [[a-z],[A-Z],[0-9],['_']]
        chance:
            Introduction: dict that key are 0-N digit and value are char_all's one dimension list subscript.
            Type: dict(int,int)
            Default: {0:0,1:0,2:0,3:0,4:0,5:1,6:1,7:1,8:2,9:3,10:3}
        start_config:
            Introduction: this function whether or not to load config file.
            Type: boolean
            Default: True
    Return:
        Introduction: list that length is equals the lens.
        Type: list(string)
        '''
        
        return getStr.getStr(mins,maxs,lens,char_all,chance)


    
    
    def getIps(lens=100,start_config=True):
        '''
    Generating a list that all are ip datas.
    IP Example: 192.168.1.1.
    Param：
        lens：
            Introduction: ip data list's length.
            Type: int
            Default: 100
        start_config:
            Introduction: this function whether or not to load config file.
            Type: boolean
            Default: True
    Return:
        Introduction: list that length is equals the lens.
        Type: list(string)
        '''
       
        return getIp.getIp(lens)




    def getPhones(lens=100,start_config=True):
        '''
    Generating a list that all are phone datas.
    Phone Example: 13012341234.
    Param：
        lens：
            Introduction: phone data list's length.
            Type: int
            Default: 100
        start_config:
            Introduction: this function whether or not to load config file.
            Type: boolean
            Default: True
    Return:
        Introduction: list that length is equals the lens.
        Type: list(string)
        '''
        
        return getPhone.getPhone(lens)

    def getChineseNames(lens=100,start_config=True):
        '''
    Generating a list that all are chinese name datas.
    Name Example: 薛鑫闻.
    Param：
        lens：
            Introduction: chinese name data list's length.
            Type: int
            Default: 100
        start_config:
            Introduction: this function whether or not to load config file.
            Type: boolean
            Default: True
    Return:
        Introduction: list that length is equals the lens.
        Type: list(string)
        '''
        
        return getName.getName(lens)
    def getDateTimes(mins='2000-01-01',maxs='2017-12-31',lens=100,start_config=True):
        '''
    Generating a list that all are datetime datas.
    Datetime Example: 2010-01-31 18:23:56.
    Param：
        mins:
            Introduction: datetime datas' min value.
            Type: string
            Default: '2000-01-01'
        maxs:
            Introduction: datetime datas' max value.
            Type: string
            Default: '2017-12-31'
        lens：
            Introduction: datetime data list's length.
            Type: int
            Default: 100
        start_config:
            Introduction: this function whether or not to load config file.
            Type: boolean
            Default: True
    Return:
        Introduction: list that length is equals the lens.
        Type: list(string)
        '''
        
        return getDateTime.getDateTime(mins,maxs,lens)
if __name__ == '__main__':
    print(Generator.getInts(lens=5))
    print(Generator.getFloats(lens=5))
    print(Generator.getIps(lens=5))
    print(Generator.getPhones(lens=5))
    print(Generator.getStrs(lens=5))
    print(Generator.getChineseNames(lens=5))
    print(Generator.getDateTimes(lens=5))
    #print(help(Generator))
    
