import random

'''
auther: dragons
date: 2018-10-17
'''
def getIp(lens):
    ip_link = [223,255,255,255]
    print('开始生成随机ip数据')
    i = 0
    bt = 0
    lists = []
    while i < lens:
        i += 1
        if int(i/lens*100) == 25 and bt == 0:
            print('已完成 25%')
            bt += 1
        elif int(i/lens*100) == 50 and bt == 1:
            print('已完成 50%')
            bt += 1
        elif int(i/lens*100) == 75 and bt == 1:
            print('已完成 75%')
            bt += 1
        ip = ''
        ip += str(random.randint(1,ip_link[0]))
        for j in range(1,4):
            ip += '.'+str(random.randint(0,ip_link[j]))
        lists.append(ip)
        
    print('已完成 100%')
    print('生成随机ip数据成功')
    return lists


if __name__ == '__main__':
    print(getIp(10))
