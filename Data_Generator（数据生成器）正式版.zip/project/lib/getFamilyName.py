#获取百家姓
import os
from getLibDir import *
from init import *
'''
auther: dragons
date: 2018-10-17
'''
#split 项目根目录名称
def getFamily(split='project'):
    split = getConfigData('basic','project_dir_name')
    lists = []
    file_dir = os.getcwd()
    file_dir = getLibDir(file_dir,split)
    #print(file_dir)
    #单姓
    with open(file_dir+r"\data\family_name1.txt",encoding='utf-8') as f:
        t = f.readlines()
        for i in t:
            for j in i:
                if j != '，' and j != '。' and j !='\n' and j!='\ufeff':
                    lists.append(j)
    #复姓
    with open(file_dir+r"\data\family_name2.txt",encoding='utf-8') as f:
        t = f.readlines()
        for i in t:
            x = 0
            s = ''
            for j in i:
                if j != '，' and j != '。' and j !='\n' and j!='\ufeff':
                    x += 1
                    s += j
                if x == 2:
                    x = 0
                    lists.append(s)
                    s = ''
    return lists
#print(",".join(lists))

if __name__=="__main__":
    lists = getFamily()
    print(lists)
