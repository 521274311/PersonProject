#484姓氏
import getFamilyName
#4606名字
import getFirstName
import random

'''
auther: dragons
date: 2018-10-17
'''
#lens 获取lens个名字的list （int）
def getName(lens):
    print("开始构建姓名模型")
    family = getFamilyName.getFamily()
    first = list(getFirstName.getFirst())
    i = 0
    family_lens = len(family)
    first_lens = len(first)
#print(family_lens)
#print(first_lens)
    bt = 0
    names = []
    print('姓名模型构建完成')
    print('开始随机生成姓名数据')
    while i<lens:
        i+=1
        if int (i / lens * 100) == 25 and bt == 0:
            print('已完成 25%')
            bt += 1
        elif int (i / lens * 100) == 50 and bt == 1:
            print('已完成 50%')
            bt += 1
        elif int (i / lens * 100) == 75 and bt == 2:
            print('已完成 75%')
            bt += 1
        name_lens = random.randint(2,4)
        name = family[random.randint(0,family_lens-1)]
        name += first[random.randint(0,first_lens-1)]
        names.append(name)
    print('已完成 100%')
    print('生成随机姓名数据成功')
    return names

if __name__=="__main__":
    print(getChineseName(1000))
