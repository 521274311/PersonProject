#通过sys包导入lib依赖包
import sys
import os

def getLibDir(path,split='project'):
    path = path.split(split)
    #print(path[0])
    
    try:
        file_dir = path[0]+split+r'\lib'
    except Exception:
        print('无法加载lib目录')
    return file_dir

#添加lib目录到sys.path中
path = os.getcwd()

#如果修改项目根目录此处需要添加split参数
path = getLibDir(path) #可能修改处

sys.path.append(path)
#导入核心生成器类
from generator import Generator

'''
auther: dragons
date: 2018-10-17
'''
if __name__ == '__main__':
    #获取随机整型数据列表
    #所有参数均为可变参数，默认 min:0, maxs:1000, lens:100
    print(Generator.getInts(mins=1,maxs=10,lens=5))

    #获取随机浮点型数据列表
    #所有参数均为可变参数，默认 min:0, maxs:1000，decimal=2，lens:100
    print(Generator.getFloats(mins=1,maxs=10,decimal=3,lens=5))

    #获取随机字符串数据列表
    #所有参数均为可变参数，默认 min:6, maxs:16, lens:100,char_all=[['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
    #                                                              ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
    #                                                              ['_'],
    #                                                              ['0','1','2','3','4','5','6','7','8','9']],
    #                           chance={0:0,1:0,2:0,3:0,4:0,5:1,6:1,7:1,8:2,9:3,10:3}
    #char_all 为随机生成字符串的字符串生成字典
    #chance 为随机成功的概率规则 key为0->N，value为0->(len(char_all)-1)
    print(Generator.getStrs(mins=1,maxs=10,lens=5,char_all=[['a','b'],['c','d']],chance={0:0,1:1}))

    #获取随机ip数据列表
    #所有参数均为可变参数，默认 len=100
    print(Generator.getIps(lens=5))

    
    #获取随机手机号码数据列表
    #所有参数均为可变参数，默认 len=100
    print(Generator.getPhones(lens=5))

    
    #获取随机中文名数据列表 （使用生成姓名前需要更换当前目录 到 lib目录）
    #所有参数均为可变参数，默认 len=100
    print(Generator.getChineseNames(lens=5))

    #获取随机日期时间数据列表
    #所有参数均为可变参数，默认 mins:'2000-01-01'，maxs:'2017-12-31'，lens:100
    print(Generator.getDateTimes(mins='2018-10-10',maxs='2018-10-10',lens=5))

    #例如 生成  姓名，年龄，出生日期   的数据
    print(list(zip(Generator.getChineseNames(lens=5),
                   Generator.getInts(mins=1,maxs=10,lens=5),
                   Generator.getDateTimes(mins='1996-01-01',maxs='2000-01-01',lens=5))))
    
